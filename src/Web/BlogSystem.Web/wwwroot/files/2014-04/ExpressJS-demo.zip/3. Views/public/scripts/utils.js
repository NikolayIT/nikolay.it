function log(message) {
    console.log(message)
}

function dialog(message) {
    alert('Attention!\n\n' + message);
}