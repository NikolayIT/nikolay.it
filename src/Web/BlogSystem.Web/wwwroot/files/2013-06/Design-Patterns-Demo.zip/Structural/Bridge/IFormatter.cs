﻿namespace Bridge
{
    internal interface IFormatter
    {
        string Format(string key, string value);
    }
}
