﻿namespace Visitor
{
    internal class President : Employee
    {
        public President()
            : base("Dick", 45000.0, 21)
        {
        }
    }
}
