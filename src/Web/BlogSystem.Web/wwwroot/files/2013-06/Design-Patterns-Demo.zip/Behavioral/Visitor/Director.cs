﻿namespace Visitor
{
    internal class Director : Employee
    {
        public Director()
            : base("Elly", 35000.0, 16)
        {
        }
    }
}
