﻿namespace Memento
{
    /// <summary>
    /// The 'Caretaker' class
    /// </summary>
    internal class ProspectMemory
    {
        public Memento Memento { get; set; }
    }
}
